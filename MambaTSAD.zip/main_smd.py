# main_smd.py
# -*- coding: utf-8 -*-
"""
SMD 多机版本 MambaTSAD 训练 + 测试入口
注意：
- 需要先用 tools/preprocess_smd.py 预处理原始 SMD 数据到 processed_root
"""

import argparse
import os
import random

import numpy as np
import torch
import torch.nn.functional as F
from torch.utils.data import DataLoader
from torch.utils.tensorboard import SummaryWriter
from tqdm import tqdm

from mambatsad.datasets.smd import build_smd_multi_datasets
from mambatsad.models.mambatsad_ts import mambatsad_ts_base
from mambatsad.utils.logger import get_logger
from mambatsad.utils.early_stopping import EarlyStopping
from mambatsad.utils.metrics import find_best_f1_threshold
from mambatsad.utils.visualization import plot_scores_with_labels


def set_seed(seed: int = 42):
    """固定随机种子，保证实验可复现"""
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)

@torch.no_grad()
def train_one_epoch(model, train_loader, optimizer, device, scaler=None, max_grad_norm=1.0, logger=None):
    model.train()
    total_loss = 0.0
    num_batches = 0

    for batch in tqdm(train_loader, desc="Train", leave=False):
        x = batch["window"]      # (B, L, D)
        if isinstance(x, torch.Tensor):
            x = x.to(device, non_blocking=True)
        else:
            x = torch.from_numpy(x).to(device, non_blocking=True)

        optimizer.zero_grad(set_to_none=True)

        # 使用新 AMP 接口
        with torch.amp.autocast("cuda", enabled=(scaler is not None)):
            out = model(x)
            # 模型返回 dict：{"recon_multi": [rec1, rec2, rec3], "recon": recon}
            rec_list = out.get("recon_multi")
            if rec_list is None:
                recon = out.get("recon")
                loss = F.mse_loss(recon, x, reduction="mean")
            else:
                loss = 0.0
                for rec in rec_list:
                    loss = loss + F.mse_loss(rec, x, reduction="mean")

        if not torch.isfinite(loss):
            if logger is not None:
                logger.warning("遇到非有限 loss (NaN/Inf)，跳过该 batch")
            continue

        if scaler is not None:
            scaler.scale(loss).backward()
            scaler.unscale_(optimizer)
            torch.nn.utils.clip_grad_norm_(model.parameters(), max_grad_norm)
            scaler.step(optimizer)
            scaler.update()
        else:
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), max_grad_norm)
            optimizer.step()

        total_loss += float(loss.detach().cpu().item())
        num_batches += 1

    avg_loss = total_loss / max(num_batches, 1)
    if logger is not None:
        logger.info(f"本 epoch 平均训练损失: {avg_loss:.6f}")
    return avg_loss


@torch.no_grad()
def evaluate_smd_multi(
    model,
    test_loader,
    win_size: int,
    labels_list,
    device,
):
    model.eval()
    num_seqs = len(labels_list)
    sum_scores = [np.zeros(len(labels_list[i]), dtype=np.float64) for i in range(num_seqs)]
    cnt_scores = [np.zeros(len(labels_list[i]), dtype=np.float64) for i in range(num_seqs)]

    for batch in tqdm(test_loader, desc="Eval", leave=False):
        x = batch["window"]
        if isinstance(x, np.ndarray):
            x_t = torch.from_numpy(x)
        else:
            x_t = x
        x_t = x_t.to(device, non_blocking=True)

        seq_idx = batch["seq_idx"]
        starts = batch["start"]
        if isinstance(seq_idx, torch.Tensor):
            seq_idx = seq_idx.cpu().numpy()
        elif not isinstance(seq_idx, np.ndarray):
            seq_idx = np.array(seq_idx, dtype=np.int64)
        if isinstance(starts, torch.Tensor):
            starts = starts.cpu().numpy()
        elif not isinstance(starts, np.ndarray):
            starts = np.array(starts, dtype=np.int64)

        out = model(x_t)
        rec = out["recon"]
        mse = ((rec - x_t) ** 2).mean(dim=-1)
        mse_np = mse.detach().cpu().numpy()

        B, L = mse_np.shape
        for i in range(B):
            k = int(seq_idx[i]); s = int(starts[i]); e = s + win_size
            sum_scores[k][s:e] += mse_np[i]
            cnt_scores[k][s:e] += 1.0

    scores_list = []
    labels_concat = []
    for k in range(num_seqs):
        c = cnt_scores[k]
        c[c == 0] = 1.0
        seq_scores = sum_scores[k] / c
        scores_list.append(seq_scores)
        labels_concat.append(labels_list[k])

    scores = np.concatenate(scores_list)
    labels_full = np.concatenate(labels_concat).astype(int)

    thr, metrics = find_best_f1_threshold(scores, labels_full)
    return scores, labels_full, thr, metrics


def parse_args():
    parser = argparse.ArgumentParser(description="MambaTSAD on SMD (multi-machine)")
    parser.add_argument("--processed_root", type=str, required=True,
                        help="SMD 预处理数据根目录，例如 ./data_processed/SMD")
    parser.add_argument("--log_dir", type=str, default="./logs/smd_all",
                        help="日志与模型保存目录（不再按 machine 拆分）")
    parser.add_argument("--win_size", type=int, default=100,
                        help="滑动窗口长度")
    parser.add_argument("--train_stride", type=int, default=1,
                        help="训练集滑动步长（一般为 1）")
    parser.add_argument("--test_stride", type=int, default=1,
                        help="测试集滑动步长（可适当加大以加速）")
    parser.add_argument("--batch_size", type=int, default=64)
    parser.add_argument("--epochs", type=int, default=50)
    parser.add_argument("--lr", type=float, default=1e-3)
    parser.add_argument("--weight_decay", type=float, default=1e-4)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--no_amp", action="store_true",
                        help="关闭混合精度训练")
    return parser.parse_args()


def main():
    args = parse_args()
    set_seed(args.seed)

    os.makedirs(args.log_dir, exist_ok=True)
    logger = get_logger(args.log_dir)
    writer = SummaryWriter(log_dir=os.path.join(args.log_dir, "tb"))

    logger.info(f"参数配置：{args}")

    # ------------ 构建多机数据集（基于预处理结果） ------------
    train_ds, test_ds, input_dim, labels_list, machine_ids = build_smd_multi_datasets(
        processed_root=args.processed_root,
        win_size=args.win_size,
        train_stride=args.train_stride,
        test_stride=args.test_stride,
    )
    logger.info(f"SMD 多机数据集构建完成："
                f"machines={machine_ids}, input_dim={input_dim}, "
                f"len(train)={len(train_ds)}, len(test)={len(test_ds)}")

    train_loader = DataLoader(
        train_ds,
        batch_size=args.batch_size,
        shuffle=True,
        num_workers=4,
        drop_last=True,
    )
    test_loader = DataLoader(
        test_ds,
        batch_size=args.batch_size,
        shuffle=False,
        num_workers=4,
    )

    # ------------ 构建模型 ------------
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model = mambatsad_ts_base(input_dim=input_dim)
    model.to(device)

    # AMP GradScaler 使用新接口以去除 FutureWarning
    scaler = None
    if not args.no_amp and device.type == "cuda":
        scaler = torch.amp.GradScaler("cuda")

    optimizer = torch.optim.AdamW(
        model.parameters(),
        lr=args.lr,
        weight_decay=args.weight_decay
    )

    early_stopper = EarlyStopping(patience=8, min_delta=1e-4, mode="max")

    best_f1 = -1.0
    best_metrics = None

    for epoch in range(1, args.epochs + 1):
        logger.info(f"========== Epoch {epoch}/{args.epochs} ==========")

        train_loss = train_one_epoch(
            model, train_loader, optimizer, device, scaler=scaler,
            max_grad_norm=1.0, logger=logger
        )

        scores, labels_full, thr, metrics = evaluate_smd_multi(
            model,
            test_loader,
            win_size=args.win_size,
            labels_list=labels_list,
            device=device,
        )
        logger.info(
            f"[Eval] F1={metrics['f1']:.4f}, "
            f"P={metrics['precision']:.4f}, R={metrics['recall']:.4f}, "
            f"AUC={metrics['auc']:.4f}, thr={metrics['threshold']:.6f}"
        )
        writer.add_scalar("eval/f1", metrics["f1"], epoch)
        writer.add_scalar("eval/precision", metrics["precision"], epoch)
        writer.add_scalar("eval/recall", metrics["recall"], epoch)
        writer.add_scalar("eval/auc", metrics["auc"], epoch)

        if metrics["f1"] > best_f1:
            best_f1 = metrics["f1"]
            torch.save(model.state_dict(), os.path.join(args.log_dir, "best_model.pt"))
            logger.info(f"发现更优模型，已保存至 {os.path.join(args.log_dir, 'best_model.pt')}" )

        vis_path = os.path.join(args.log_dir, f"scores_epoch{epoch}.png")
        plot_scores_with_labels(
            scores=scores,
            labels=labels_full,
            threshold=thr,
            save_path=vis_path,
            max_points=2000,
        )
        logger.info(f"已保存可视化图：{vis_path}")

    logger.info(f"训练结束，最佳 F1={best_f1:.4f}, 最佳指标={best_metrics}")
    # device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    # model = mambatsad_ts_base(input_dim=input_dim).to(device)
    # logger.info(f"模型结构：\n{model}")
    #
    # optimizer = torch.optim.AdamW(
    #     model.parameters(),
    #     lr=args.lr,
    #     weight_decay=args.weight_decay,
    # )
    # scaler = torch.cuda.amp.GradScaler(enabled=not args.no_amp)
    #
    # best_f1 = -1.0
    # best_ckpt_path = os.path.join(args.log_dir, "best_model.pt")
    #
    # # ------------ 训练主循环 ------------
    # for epoch in range(1, args.epochs + 1):
    #     train_loss = train_one_epoch(
    #         model,
    #         train_loader,
    #         optimizer,
    #         device=device,
    #         scaler=scaler if not args.no_amp else None,
    #     )
    #
    #     logger.info(f"[Epoch {epoch}/{args.epochs}] train_loss={train_loss:.6f}")
    #     writer.add_scalar("train/loss", train_loss, epoch)
    #
    #     scores, labels_full, thr, metrics = evaluate_smd_multi(
    #         model,
    #         test_loader,
    #         win_size=args.win_size,
    #         labels_list=labels_list,
    #         device=device,
    #     )
    #     logger.info(
    #         f"[Eval] F1={metrics['f1']:.4f}, "
    #         f"P={metrics['precision']:.4f}, R={metrics['recall']:.4f}, "
    #         f"AUC={metrics['auc']:.4f}, thr={metrics['threshold']:.6f}"
    #     )
    #     writer.add_scalar("eval/f1", metrics["f1"], epoch)
    #     writer.add_scalar("eval/precision", metrics["precision"], epoch)
    #     writer.add_scalar("eval/recall", metrics["recall"], epoch)
    #     writer.add_scalar("eval/auc", metrics["auc"], epoch)
    #
    #     if metrics["f1"] > best_f1:
    #         best_f1 = metrics["f1"]
    #         torch.save(model.state_dict(), best_ckpt_path)
    #         logger.info(f"发现更优模型，已保存至 {best_ckpt_path}")
    #
    #     vis_path = os.path.join(args.log_dir, f"scores_epoch{epoch}.png")
    #     plot_scores_with_labels(
    #         scores=scores,
    #         labels=labels_full,
    #         threshold=thr,
    #         save_path=vis_path,
    #         max_points=2000,
    #     )
    #     logger.info(f"已保存可视化图：{vis_path}")
    #
    # logger.info(f"训练完成！最佳 F1={best_f1:.4f}，模型保存在 {best_ckpt_path}")


if __name__ == "__main__":
    main()
