# utils/ts_postprocess.py

import numpy as np

def point_adjust(pred_labels: np.ndarray, gt_labels: np.ndarray) -> np.ndarray:
    """
    经典 point-adjust：
    - 对于每一段连续的真实异常区间，如果预测中有任何一个点被判为异常，
      则把该区间内所有点都置为异常。
    - 该机制在 OmniAnomaly、USAD 等时间序列异常检测工作中广泛使用。

    pred_labels: 预测标签，0/1，一维数组
    gt_labels:   真实标签，0/1，一维数组
    """
    pred = pred_labels.astype(int).copy()
    gt = gt_labels.astype(int)
    n = len(gt)
    i = 0
    while i < n:
        if gt[i] == 1:
            # 找到一段连续的异常区间 [i, j)
            j = i + 1
            while j < n and gt[j] == 1:
                j += 1

            # 如果这段里预测过至少一个点异常，则整段都置为 1
            if pred[i:j].sum() > 0:
                pred[i:j] = 1

            i = j
        else:
            i += 1
    return pred
