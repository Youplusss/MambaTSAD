# -*- coding: utf-8 -*-
"""
评估指标相关函数：
- 根据时点级别分数 + label，搜索最优阈值，返回 F1 / P / R
"""

import numpy as np
from sklearn.metrics import precision_recall_fscore_support, roc_auc_score
# from ts_postprocess import point_adjust
from mambatsad.utils.ts_postprocess import point_adjust


def find_best_f1_threshold(
    scores: np.ndarray,
    labels: np.ndarray,
    num_thresh: int = 200,
):
    """
    在给定区间内均匀枚举阈值，找到 F1 分数最高的阈值
    scores: [T]，越大越异常
    labels: [T]，0/1
    """
    assert scores.shape == labels.shape
    s_min, s_max = float(scores.min()), float(scores.max())
    if s_max == s_min:
        # 所有分数都一样，直接返回 0
        thr = s_max
        prec, rec, f1, _ = precision_recall_fscore_support(
            labels, scores > thr, average="binary", zero_division=0
        )
        return thr, {"precision": prec, "recall": rec, "f1": f1, "auc": 0.5}

    thresholds = np.linspace(s_min, s_max, num_thresh)
    best_f1 = -1
    best_thr = thresholds[0]
    best_metrics = {}

    for thr in thresholds:
        preds = (scores > thr).astype(int)
        prec, rec, f1, _ = precision_recall_fscore_support(
            labels, preds, average="binary", zero_division=0
        )
        if f1 > best_f1:
            best_f1 = f1
            best_thr = thr
            best_metrics = {"precision": prec, "recall": rec, "f1": f1}

    # AUC 作为参考指标
    try:
        auc = roc_auc_score(labels, scores)
    except ValueError:
        auc = 0.5
    best_metrics["auc"] = auc
    best_metrics["threshold"] = best_thr
    return best_thr, best_metrics


def search_best_f1_with_point_adjust(scores, labels, n_thresholds: int = 200, use_point_adjust: bool = True):
    """
    根据得分搜索最佳 F1 的阈值（支持 point_adjust）。
    scores: 一维数组，越大越异常
    labels: 一维 0/1 数组
    """
    scores = np.asarray(scores, dtype=np.float64)
    labels = np.asarray(labels, dtype=int)

    # 计算 AUC
    try:
        auc = roc_auc_score(labels, scores)
    except ValueError:
        # 全 0 或全 1 的情况
        auc = float("nan")

    min_s, max_s = float(scores.min()), float(scores.max())
    if min_s == max_s:
        # 所有得分一样，完全没有区分度
        best_thr = min_s
        preds = np.ones_like(labels)  # 或全 0，看你想要哪种行为
        if use_point_adjust:
            preds = point_adjust(preds, labels)
        P = precision_score(labels, preds, zero_division=0)
        R = recall_score(labels, preds, zero_division=0)
        F1 = f1_score(labels, preds, zero_division=0)
        return {
            "best_thr": best_thr,
            "f1": F1,
            "precision": P,
            "recall": R,
            "auc": auc,
        }

    # 选 n_thresholds 个等间隔阈值（包含 min/max）
    thresholds = np.linspace(min_s, max_s, num=n_thresholds)

    best = {
        "best_thr": thresholds[0],
        "f1": -1.0,
        "precision": 0.0,
        "recall": 0.0,
        "auc": auc,
    }

    for thr in thresholds:
        preds = (scores >= thr).astype(int)
        if use_point_adjust:
            preds = point_adjust(preds, labels)

        P = precision_score(labels, preds, zero_division=0)
        R = recall_score(labels, preds, zero_division=0)
        F1 = f1_score(labels, preds, zero_division=0)

        if F1 > best["f1"]:
            best.update({
                "best_thr": float(thr),
                "f1": float(F1),
                "precision": float(P),
                "recall": float(R),
            })

    return best
